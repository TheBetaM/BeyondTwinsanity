Vicarious Visions GOB TOOLS CNK Readme
Created by Nick Whitlock
Updated for Crash Nitro Kart by BetaM and ManDude
Contact: Original: eezstreet@live.com / CNK version: @mat5b on Twitter

TABLE OF CONTENTS
- WHAT IS IT?
- WHAT IS INCLUDED?
- WHAT GAMES ARE SUPPORTED?
- HOW DO I USE GOBEXTRACT?
- HOW DO I USE GOBCONVERT?
- LICENSE INFORMATION

WHAT IS IT?
GOB is an archive format that is used by Vicarious Visions. It has been used in numerous games from the mid 2000s, all of them on consoles. These tools allow you to work with .gob files.

WHAT IS INCLUDED?
- gobextract (extractor and builder tool)

WHAT GAMES ARE SUPPORTED?
All versions of Crash Nitro Kart are supported.

HOW DO I USE GOBEXTRACT?
gobextract is a commandline tool that can extract or display information about a GOB/GFC pair.
To use it, you'll need to have BOTH the GOB and the GFC in the same directory.
Invoking it via the commandline is relatively straightforward:

gobextract <gob file> <input/output directory> [-debug] [-cache] [-echodata] [-noextract] [-create <compression level>]

Any parameter in <> is mandatory, anything in [] is optional.
-debug turns on extra debug information, including memory allocations
-cache turns on GOB caching. It compromises performance for RAM usage, but may not work correctly. Turning it on is not recommended.
-echodata turns on metadata reporting. It will peek at file names, modification dates and more. Piping the output to a file is STRONGLY recommended.
-noextract will tell gobextract to not extract any files. Useful if used with -echodata to "spy" on the data inside without extracting it.
-create will build the directory into a GOB/GFC pair using the specified compression level.

If the parameters are wrong, it will print the usage.
The GOB file parameter does not require an extension.
Forward slashes or backslashes both work for the output directory and gob file path.

LICENSE INFORMATION
The GOB format is an archive format created by Vicarious Visions. By reading this README file you are accepting the terms and conditions of the license file.